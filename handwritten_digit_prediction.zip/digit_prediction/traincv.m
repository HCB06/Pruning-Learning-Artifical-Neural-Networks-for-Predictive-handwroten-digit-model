function traincv ()

sayi = 1;

disp('training');

[hid3_vis,out_vis] = gorsel();

do

photo = sprintf('train/%d.png',sayi);

img = imread(photo);

img = rgb2gray(img);

subplot(1,2,1);
imshow(img);
title("Öğrenilen Görüntü");

input_layer = img(:);


hidden_layer1 = zeros(392);
hidden_layer2 = zeros(196);
hidden_layer3 = zeros(28);
output_layer = zeros(9);

weight1 = rand(392,784);
weight2 = rand(196,392);
weight3 = rand(28,196);
weight4 = rand(9,28);

optimizasyon(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4,sayi,hid3_vis,out_vis);

sayi++;

until(sayi>9)

disp('train finished');

disp('validation starting in 3..');
pause(3)

validate

