function [matris] = olcekleme(matris)


		min_value = min(matris(:));
		max_value = max(matris(:));
		
		matris = 0 + (matris - min_value) * (1 - 0) / (max_value - min_value); % Ölçeklendirme