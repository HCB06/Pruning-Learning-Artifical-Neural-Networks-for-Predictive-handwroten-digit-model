function [input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4] = snn(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4,hid3_vis,out_vis)
 
	inp_vis = zeros(784,1);
	hid1_vis = zeros(592,1);
	hid2_vis = zeros(496,1);

	
	
	%{
	for i = 1:length(inp_vis)
    inp_vis(i) = i;
	end
	
	for i = 200:length(hid1_vis)
    hid1_vis(i) = i;
	end
	
	for i = 300:length(hid2_vis)
    hid2_vis(i) = i;
	end
	%}
	

	

	%{
	plot(1,inp_vis,'.','color', [0.5, 0.5, 0.5]);
	
	plot(2,hid1_vis,'.','color', [0.5, 0.5, 0.5]);
	hold on
	plot(3,hid2_vis,'.','color', [0.5, 0.5, 0.5]);
	hold on
	%}
	

	i = 1;
	c = ones(392) / 2;
	t = zeros(392);
	
	do
		
		if input_layer(i) == 0
		
			weight1(:,i) = 0;
			
		
		end
		%{
		if input_layer(i) > 254
			
		j = 201;
		
		subplot(2,1,1);
		plot(1,inp_vis(i),'.c');
		
		
		do
			
			x = [1,2];
			y = [i,j-1];
			subplot(2,1,1);
			
			if weight1(j-200,i) < 0.75
			plot(x,y,'color',[0.2, 0.4, 0.2]);
			
			elseif weight1(j-200,i) < 0.85 && weight1(j-200,i) > 0.75
			plot(x, y, 'color',[0.2, 0.7, 0.2]);
			
			elseif weight1(j-200,i) < 0.100 && weight1(j-200,i) > 0.85
			plot(x,y,'color',[0.2, 1.0, 0.2]);
			end
			
			plot(2, hid1_vis(j-1),'.c');
			
			pause(0.001);
			
			plot(2, hid1_vis(j-1),'color', [0.5, 0.5, 0.5]);
			
			c(j-200) += weight1(j-200,i) / 100;
			t(j-200) += weight1(j-200,i);
			
			if c(j-200) >= 1
			c(j-200) = 0.99;
			t(j-200) += 1;
			end
			
			if t(j-200) == 0
			
			t(j-200) = 0.001;
			
			end
			
			plot(2, hid1_vis(j-1), '.', 'color', [0.5, c(j-200), 0.5] , 'markersize', t(j-200));
			
			subplot(2,1,2);
			
			plot(1:j-200,t(1:j-200),'r-');
			title('Spiking Aktiviteleri');
			xlabel('Nöron');
			ylabel('Aksiyon Potansiyeli');
			axis([0 392 0 100])
			hold off
			
		j++;
		until(j>592)
			hold off
		end
		%}
		i++;
		
		until(i>784)
		

		hidden_layer1 = (weight1 * input_layer);
		
	
		[hidden_layer1] = olcekleme(hidden_layer1);
		
		hidden_layer1 = 1 ./ (1 + exp(-hidden_layer1)); % Sigmoid

		
		i = 1;
		c = ones(196) / 2;
		t = zeros(196);
		
		do
		
		if hidden_layer1(i) < 0.65
		
			weight2(:,i) = 0;
		
		end
		%{
		if hidden_layer1(i) >= 0.65
		
			
		j = 301;
		subplot(2,1,1);
		plot(2,hid1_vis(i),'.c');
		
		do
			
			x = [2,3];
			y = [i+200,j-1];
			subplot(2,1,1);
			
		if weight2(j-300,i) < 0.75
			plot(x,y,'color',[0.2, 0.4, 0.2]);
			
			elseif weight2(j-300,i) < 0.85 && weight2(j-300,i) > 0.75
			plot(x, y, 'color',[0.2, 0.7, 0.2]);
			
			elseif weight2(j-300,i) < 0.100 && weight2(j-300,i) > 0.85
			plot(x,y,'color',[0.2, 1.0, 0.2]);
			end
			
			plot(3, hid2_vis(j-1),'.c');
			
			pause(0.001);
			
			plot(3, hid2_vis(j-1),'color', [0.5, 0.5, 0.5]);
			c += weight2(j-300,i) / 100;
			t(j-300) += weight2(j-300,i);
			if c(j-300) >= 1
			c(j-300) = 0.99;
			t(j-300) += 1;
			end
			
			if t(j-300) == 0
			
			t(j-300) = 0.001;
			
			end
			plot(3,hid2_vis(j-1),'.','color', [0.5, c(j-300), 0.5] , 'markersize', t(j-300));
			
			subplot(2,1,2);
			
			plot(1:j-300,t(1:j-300),'r-');
			title('Spiking Aktiviteleri');
			xlabel('Nöron');
			ylabel('Aksiyon Potansiyeli');
			axis([0 196 0 75])
			hold off
			
		j++;
		until(j>496)
		hold off
		end
		%}
		i++;
		
		until(i>392)
		
		
		
		hidden_layer2 = (weight2 * hidden_layer1);
		
		
	
	
		[hidden_layer2] = olcekleme(hidden_layer2);
		
		hidden_layer2 = 1 ./ (1 + exp(-hidden_layer2)); % Sigmoid
		
		
		i = 1;
		c = ones(28) / 2;
		t = zeros(28);
	
		do
		
		
		if hidden_layer2(i) < 0.65
		
			weight3(:,i) = 0;
		
		end
		%{
		if hidden_layer2(i) >= 0.65
			
		j = 401;
		subplot(2,1,1);
		plot(3,hid2_vis(i),'.c');
		
		do
			
			x = [3,4];
			y = [i+300,j-1];
			subplot(2,1,1);
			
			if weight3(j-400,i) < 0.75
			plot(x,y,'color',[0.2, 0.4, 0.2]);
			
			elseif weight3(j-400,i) < 0.85 && weight3(j-400,i) > 0.75
			plot(x, y, 'color',[0.2, 0.7, 0.2]);
			
			elseif weight3(j-400,i) < 0.100 && weight3(j-400,i) > 0.85
			plot(x,y,'color',[0.2, 1.0, 0.2]);
			end
			
			plot(4, hid3_vis(j-1),'.c');
			
			pause(0.001);
			
			plot(4, hid3_vis(j-1),'color', [0.5, 0.5, 0.5]);
			
			c += weight3(j-400,i) / 100;
			t(j-400) += weight3(j-400,i);
			if c(j-400) >= 1
			c(j-400) = 0.99;
			t(j-400) += 1;
			end
			
			if t(j-400) == 0
			
			t(j-400) = 0.001;
			
			end
			
			plot(4,hid3_vis(j-1),'.','color', [0.5, c(j-400), 0.5] , 'markersize', t(j-400));
		
			subplot(2,1,2);
			
			plot(1:j-400,t(1:j-400),'r-');
			title('Spiking Aktiviteleri');
			xlabel('Nöron');
			ylabel('Aksiyon Potansiyeli');
			axis([0 28 0 50])
			hold off
			
		j++;
		until(j>428)
			hold off
		end
		%}
		i++;
		
		until(i>196)
		
		
		
		hidden_layer3 = (weight3 * hidden_layer2);
		
		
	
	
		[hidden_layer3] = olcekleme(hidden_layer3);
		
		hidden_layer3 = 1 ./ (1 + exp(-hidden_layer3)); % Sigmoid
		
		
		subplot(1,2,2);
		delete(findobj(gca, 'Type', 'line', 'Color', [0.2, 0.4, 0.2]));
		delete(findobj(gca, 'Type', 'line', 'Color', [0.2, 0.7, 0.2]));
		delete(findobj(gca, 'Type', 'line', 'Color', [0.2, 1.0, 0.2]));
		i = 1;
		c = ones(9) / 2;
		t = zeros(9);
		
		do
		
		if hidden_layer3(i) < 0.65
		
			weight4(:,i) = 0;
		
		end
		
		ymin = 400;
		ymax = 428;
		
		if hidden_layer3(i) >= 0.65
			
		j = 411;
		subplot(1,2,2);
		plot(1,hid3_vis(i),'.c', 'MarkerSize', 20);
		ylim([ymin ymax]);
		
		do
			
			x = [1,2];
			y = [i+401,j-1];
			subplot(1,2,2);
			if weight4(j-410,i) < 0.75
			plot(x,y,'color',[0.2, 0.4, 0.2]);
			ylim([ymin ymax]);
			
			elseif weight4(j-410,i) < 0.85 && weight4(j-410,i) > 0.75
			plot(x, y, 'color',[0.2, 0.7, 0.2]);
			ylim([ymin ymax]);
			
			elseif weight4(j-410,i) < 0.100 && weight4(j-410,i) > 0.85
			plot(x,y,'color',[0.2, 1.0, 0.2]);
			ylim([ymin ymax]);
			
			end
			
			plot(2, out_vis(j-1),'.c', 'MarkerSize', 20);
			ylim([ymin ymax]);
			
			plot(2, out_vis(j-1),'color', [0.5, 0.5, 0.5]);
			ylim([ymin ymax]);
			c += weight4(j-410,i) / 100;
			t(j-410) += weight4(j-410,i);
			if c(j-410) >= 1
			c(j-410) = 0.99;
			t(j-410) += 1;
			end
			
			if t(j-410) == 0
			
			t(j-410) = 0.001;
			
			end
			plot(2,out_vis(j-1),'.','color', [0.5, c(j-410), 0.5] , 'MarkerSize', 20);
			ylim([ymin ymax]);
			%{
			subplot(2,1,2);

			plot(1:j-410,t(1:j-410),'r-');
			title('Spiking Aktiviteleri');
			xlabel('Nöron');
			ylabel('Aksiyon Potansiyeli');
			axis([0 9 0 25])
			hold off
			%}
		j++;
		until(j>419)
		
			pause(0.001);
			
		end
		
		i++;
		
		until(i>28)
		
		subplot(1,2,2);
		
		output_layer = (weight4 * hidden_layer3);
		
	
		output_layer = output_layer';
		
		h = exp(output_layer);
		output_layer = h / sum(h); % Softmax,
		
		i = 1;
		
		do
		
		if output_layer(i) >= 0.11
		
			plot(2,out_vis(i),'.c', 'MarkerSize', 20);
			ylim([ymin ymax]);
		end
		
		i++;
		
		until(i>9)
		
		
		i = 1;
		
		do 
		
		if max(output_layer) == output_layer(i)
		
		plot(2,out_vis(409+i),'.g', 'MarkerSize', 20);
		ylim([ymin ymax]);
		
		end
		
		i++;
		
		until(i>9)