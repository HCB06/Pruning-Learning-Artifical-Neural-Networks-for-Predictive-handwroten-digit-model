function testcv ()

i = 1;

disp('testing');

[hid3_vis,out_vis] = gorsel();

do

sayi = randi([1,66]);

photo = sprintf('test/%d.png',sayi);

img = imread(photo);
img = double(img);
img = rgb2gray(img);

input_layer = img(:);
input_layer = double(input_layer);

hidden_layer1 = zeros(392);
hidden_layer2 = zeros(196);
hidden_layer3 = zeros(28);
output_layer = zeros(9);


		dosyaAdi = sprintf('bilgiler/weight1.mat');
    load(dosyaAdi);
    
		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
    load(dosyaAdi2);
	
	dosyaAdi3 = sprintf('bilgiler/weight3.mat');
    load(dosyaAdi3);

	dosyaAdi4 = sprintf('bilgiler/weight4.mat');
    load(dosyaAdi4);
o = 'None';
subplot(1,2,1);
imshow(img);
title(o);
hold on
	
[input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4] = snn(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4,hid3_vis,out_vis);


disp(max(output_layer));


j = 1;

do

 if max(output_layer) == output_layer(j)
 
 disp(j);
 
 o = j;
 
 end
 j++;
 
 until(j>9)

subplot(1,2,1);
imshow(img);
title(o);
hold on

i++;

pause(1)

until(i>100)

key = input('want a improved test ? "y" or "n".', 's');
    
    if strcmp(key, 'y')
        improved_test
    elseif strcmp(key, 'n')
		disp('program closing in 10');
		pause(10)
	end
	
end