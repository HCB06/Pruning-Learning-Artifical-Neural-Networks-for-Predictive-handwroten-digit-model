function [hid3_vis,out_vis] = gorsel()

	hid3_vis = zeros(428,1);
	out_vis = zeros(419,1);
	
	for i = 400:length(hid3_vis)
    hid3_vis(i) = i;
	end
	
	for i = 410:length(out_vis)
    out_vis(i) = i;
	end

	
	subplot(1,2,2);
	plot(1, hid3_vis, '.', 'Color', [0.5, 0.5, 0.5], 'MarkerSize', 20);
	
	xlabel('Katmanlar');
	ylabel('Nöronlar');
	title('SNN(%2.5)');
	hold on
	
	plot(2,out_vis,'.','color', [0.5, 0.5, 0.5], 'MarkerSize', 20);
	hold on
	
	end