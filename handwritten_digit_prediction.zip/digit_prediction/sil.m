function sil ()

	dosyaAdi = sprintf('bilgiler/weight1.mat');
    load(dosyaAdi);
    
		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
    load(dosyaAdi2);
	
	dosyaAdi3 = sprintf('bilgiler/weight3.mat');
    load(dosyaAdi3);
	
	dosyaAdi4 = sprintf('bilgiler/weight4.mat');
    load(dosyaAdi4);
	
	
	
	weight1(:,:) = 0;
	
	weight2(:,:) = 0;

	weight3(:,:) = 0;

	weight4(:,:) = 0;
	
		dosyaAdi1 = sprintf('bilgiler/weight1.mat');
	save(dosyaAdi1, 'weight1');

		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
	save(dosyaAdi2, 'weight2'); 

		dosyaAdi3 = sprintf('bilgiler/weight3.mat');
	save(dosyaAdi3, 'weight3');

		dosyaAdi4 = sprintf('bilgiler/weight4.mat');
	save(dosyaAdi4, 'weight4'); 
	
	disp('öğrenilen bilgiler silindi. starting training..');
	
	traincv