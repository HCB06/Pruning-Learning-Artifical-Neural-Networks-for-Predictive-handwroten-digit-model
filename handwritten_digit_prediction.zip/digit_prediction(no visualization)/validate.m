function validate ()

sayi = 1;

h = 0;

disp('validating');

do

try
photo = sprintf('train/%d.png',sayi);

img = imread(photo);

img = double(img);
img = rgb2gray(img);

input_layer = img(:);
input_layer = double(input_layer);
catch

validate()

end
hidden_layer1 = zeros(392);
hidden_layer2 = zeros(196);
hidden_layer3 = zeros(28);
output_layer = zeros(9);


		dosyaAdi = sprintf('bilgiler/weight1.mat');
    load(dosyaAdi);
    
		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
    load(dosyaAdi2);
	
	dosyaAdi3 = sprintf('bilgiler/weight3.mat');
    load(dosyaAdi3);

	dosyaAdi4 = sprintf('bilgiler/weight4.mat');
    load(dosyaAdi4);
o = 'None';

imshow(img);
title(o);
hold on
	
[input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4] = snn(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4);


disp(max(output_layer));

i = 1;

do

 if max(output_layer) == output_layer(i)
 
 disp(i);
 
 o = i;
 
 end
 i++;
 
 until(i>9)


imshow(img);
title(o);
hold on

if o ~= sayi

h++;

end
pause(1)

sayi++;

until(sayi>9)

disp(['Hata sayısı: ' num2str(h)]);

key = input('press "y" for test or "n" for re-train.', 's');
    
    if strcmp(key, 'y')
        testcv
    elseif strcmp(key, 'n')
		sil
	end
	
	
end

