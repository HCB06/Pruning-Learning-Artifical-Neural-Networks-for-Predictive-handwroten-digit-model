function improved_test ()


disp('customize testing');
disp('sıfırlamak için sağ alt köşeye tıklayın. / for reset click right down corner.');

t = 1;

do

photo = sprintf('custom.png');

img = imread(photo);
img = double(img);
%img = rgb2gray(img);

input_layer = img(:);
input_layer = double(input_layer);

hidden_layer1 = zeros(392);
hidden_layer2 = zeros(196);
hidden_layer3 = zeros(28);
output_layer = zeros(9);


		dosyaAdi = sprintf('bilgiler/weight1.mat');
    load(dosyaAdi);
    
		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
    load(dosyaAdi2);
	
	dosyaAdi3 = sprintf('bilgiler/weight3.mat');
    load(dosyaAdi3);

	dosyaAdi4 = sprintf('bilgiler/weight4.mat');
    load(dosyaAdi4);
o = 'None';

imshow(img);
title(o);
hold on

[input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4] = snn(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4);


disp(max(output_layer));


j = 1;

do

 if max(output_layer) == output_layer(j)
 
 disp(j);
 
 o = j;
 
 end
 j++;
 
 until(j>9)

imshow(img);
title(o);
hold on

[x, y] = ginput(1);

x = round(x);
y = round(y);

img(y, x) = 255;

if x == 28 && y == 28

img = zeros(28,28);

end


	custom = img;
		imwrite(uint8(custom), 'custom.png');
	
	t++;
	
	until(t>1000)
	
end