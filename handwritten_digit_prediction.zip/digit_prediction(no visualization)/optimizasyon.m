function [weight1,weight2,weight3,weight4] = optimizasyon(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4,sayi)

input_layer = double(input_layer);

do
do

weight1 = rand(392,784);
weight2 = rand(196,392);
weight3 = rand(28,196);
weight4 = rand(9,28);

if sayi == 1

weight1(43:392,:) = 0;
weight2(20:196,:) = 0;
weight3(3:28,:) = 0;
weight4(2:9,:) = 0;

elseif sayi == 2

weight1(1:42,:) = 0;
weight1(86:392,:) = 0;

weight2(1:19,:) = 0;
weight2(40:196,:) = 0;

weight3(1:2,:) = 0;
weight3(6:28,:) = 0;

weight4(1,:) = 0;
weight4(3:9,:) = 0;

elseif sayi == 3

weight1(1:85,:) = 0;
weight1(118:392,:) = 0;

weight2(1:39,:) = 0;
weight2(60:196,:) = 0;

weight3(1:5,:) = 0;
weight3(8:28,:) = 0;

weight4(1:2,:) = 0;
weight4(4:9,:) = 0;

elseif sayi == 4

weight1(1:117,:) = 0;
weight1(160:392,:) = 0;

weight2(1:59,:) = 0;
weight2(80:196,:) = 0;

weight3(1:7,:) = 0;
weight3(10:28,:) = 0;

weight4(1:3,:) = 0;
weight4(5:9,:) = 0;

elseif sayi == 5

weight1(1:159,:) = 0;
weight1(193:392,:) = 0;

weight2(1:79,:) = 0;
weight2(100:196,:) = 0;

weight3(1:9,:) = 0;
weight3(12:28,:) = 0;

weight4(1:4,:) = 0;
weight4(6:9,:) = 0;

elseif sayi == 6

weight1(1:192,:) = 0;
weight1(235:392,:) = 0;

weight2(1:99,:) = 0;
weight2(120:196,:) = 0;

weight3(1:12,:) = 0;
weight3(15:28,:) = 0;

weight4(1:5,:) = 0;
weight4(7:9,:) = 0;

elseif sayi == 7

weight1(1:234,:) = 0;
weight1(277:392,:) = 0;

weight2(1:119,:) = 0;
weight2(140:196,:) = 0;

weight3(1:15,:) = 0;
weight3(18:28,:) = 0;

weight4(1:6,:) = 0;
weight4(8:9,:) = 0;

elseif sayi == 8

weight1(1:276,:) = 0;
weight1(320:392,:) = 0;

weight2(1:139,:) = 0;
weight2(160:196,:) = 0;

weight3(1:18,:) = 0;
weight3(21:28,:) = 0;

weight4(1:7,:) = 0;
weight4(9,:) = 0;

elseif sayi == 9

weight1(1:319,:) = 0;
weight1(362:392,:) = 0;

weight2(1:159,:) = 0;
weight2(180:196,:) = 0;

weight3(1:21,:) = 0;
weight3(24:28,:) = 0;

weight4(1:8,:) = 0;

end

	
[input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4] = snn(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4);


output_layer

until(output_layer(sayi) > 0.1)
until(output_layer(sayi) < 0.12)


	
	if sayi ~= 1
	
		w1 = weight1;
		w2 = weight2;
		w3 = weight3;
		w4 = weight4;
		
		dosyaAdi = sprintf('bilgiler/weight1.mat');
    load(dosyaAdi);
    
		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
    load(dosyaAdi2);
	
	dosyaAdi3 = sprintf('bilgiler/weight3.mat');
    load(dosyaAdi3);
	
	dosyaAdi4 = sprintf('bilgiler/weight4.mat');
    load(dosyaAdi4);
		
		
		weight1 += w1;
		weight2 += w2;
		weight3 += w3;
		weight4 += w4;

end


		dosyaAdi1 = sprintf('bilgiler/weight1.mat');
	save(dosyaAdi1, 'weight1');

		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
	save(dosyaAdi2, 'weight2'); 

		dosyaAdi3 = sprintf('bilgiler/weight3.mat');
	save(dosyaAdi3, 'weight3');

		dosyaAdi4 = sprintf('bilgiler/weight4.mat');
	save(dosyaAdi4, 'weight4'); 
		
		