function [input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4] = snn(input_layer,hidden_layer1,hidden_layer2,hidden_layer3,output_layer,weight1,weight2,weight3,weight4)
 

	i = 1;
		
	
		do
		
		if input_layer(i) == 0
		
			weight1(:,i) = 0;
		
		end
		
		i++;
		
		until(i>784)
		
		
		
		hidden_layer1 = (weight1 * input_layer);
		
	
		[hidden_layer1] = olcekleme(hidden_layer1);
		
		hidden_layer1 = 1 ./ (1 + exp(-hidden_layer1)); % Sigmoid
		
		subplot(2,3,2);
		
		i = 1;
		
	
		do
		
		if hidden_layer1(i) < 0.65
		
			weight2(:,i) = 0;
		
		end
		
		i++;
		
		until(i>392)
		
		
		
		hidden_layer2 = (weight2 * hidden_layer1);
		
		
	
	
		[hidden_layer2] = olcekleme(hidden_layer2);
		
		hidden_layer2 = 1 ./ (1 + exp(-hidden_layer2)); % Sigmoid
		
		
		i = 1;
		
	
		do
		
		if hidden_layer2(i) < 0.65
		
			weight3(:,i) = 0;
		
		end
		
		i++;
		
		until(i>196)
		
		
		
		hidden_layer3 = (weight3 * hidden_layer2);
		
		
	
	
		[hidden_layer3] = olcekleme(hidden_layer3);
		
		hidden_layer3 = 1 ./ (1 + exp(-hidden_layer3)); % Sigmoid
		
	
		
		i = 1;
		
		do
		
		if hidden_layer3(i) < 0.65
		
			weight4(:,i) = 0;
		
		end
		
		
		i++;
		
		until(i>28)
		
		
		
		output_layer = (weight4 * hidden_layer3);
		
	
		output_layer = output_layer';
		
		h = exp(output_layer);
		output_layer = h / sum(h); % Softmax